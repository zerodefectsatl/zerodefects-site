Zero Defects ATL — Static React (CDN) Site
================================================

How to Deploy on Vercel (No Build Needed)
-----------------------------------------
1) Go to vercel.com -> New Project -> Import -> "Import Third-Party Git Repository" -> "Deploy Without Git" and upload the *entire* folder contents.
   OR drag-and-drop this folder onto the Vercel dashboard.
2) After deploy, add your domain under Project -> Settings -> Domains:
   - Root (@) A record -> 76.76.21.21
   - www CNAME -> cname.vercel-dns.com
3) SSL will issue automatically.

Editing
-------
- Open app.js to edit copy, service areas, images, and contact info.
- Replace Unsplash placeholders with your real photos.
- For forms beyond mailto:, message your dev to wire a serverless function.

SEO/AEO/GEO
-----------
- index.html includes OG/robots/meta; app.js injects JSON-LD for LocalBusiness, Services, and FAQ.
- sitemap.xml and robots.txt are included.

Contact
-------
Phone: (404) 406-3355
Email: zerodefectsatl@gmail.com
